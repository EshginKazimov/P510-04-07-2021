﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBackP510.Models
{
    public class SliderImage
    {
        public int Id { get; set; }

        public string Image { get; set; }
    }
}
