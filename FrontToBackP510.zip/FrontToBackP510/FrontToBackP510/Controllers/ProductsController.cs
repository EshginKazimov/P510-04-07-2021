﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP510.DataAccessLayer;
using Microsoft.EntityFrameworkCore;

namespace FrontToBackP510.Controllers
{
    public class ProductsController : Controller
    {
        private readonly AppDbContext _dbContext;

        public ProductsController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> Index()
        {
            //var products = await _dbContext.Products.Include(x => x.Category).ToListAsync();

            return View(/*products*/);
        }

        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null)
                return NotFound();

            var product = await _dbContext.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            return View(product);
        }
    }
}
