﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP510.DataAccessLayer;
using FrontToBackP510.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace FrontToBackP510.ViewComponents
{
    public class HeaderViewComponent : ViewComponent
    {
        private readonly AppDbContext _dbContext;

        public HeaderViewComponent(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            ViewBag.Count = 0;
            var basketCookie = Request.Cookies["basket"];
            if (!string.IsNullOrEmpty(basketCookie))
            {
                var basketViewModels = JsonConvert.DeserializeObject<List<BasketViewModel>>(basketCookie);
                ViewBag.Count = basketViewModels.Count;
            }

            var bio = await _dbContext.Bios.FirstOrDefaultAsync();

            return View(bio);
        }
    }
}
